'use strict';

// Business logic for category — called from the controller.
// Keeps controllers thin and services testable.

module.exports = {};
