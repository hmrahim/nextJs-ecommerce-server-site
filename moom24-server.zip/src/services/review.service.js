'use strict';

// Business logic for review — called from the controller.
// Keeps controllers thin and services testable.

module.exports = {};
