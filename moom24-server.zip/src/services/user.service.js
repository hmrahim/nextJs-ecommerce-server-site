'use strict';

// Business logic for user — called from the controller.
// Keeps controllers thin and services testable.

module.exports = {};
