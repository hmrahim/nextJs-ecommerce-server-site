'use strict';

// Business logic for notification — called from the controller.
// Keeps controllers thin and services testable.

module.exports = {};
