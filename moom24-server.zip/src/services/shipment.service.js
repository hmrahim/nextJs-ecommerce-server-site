'use strict';

// Business logic for shipment — called from the controller.
// Keeps controllers thin and services testable.

module.exports = {};
