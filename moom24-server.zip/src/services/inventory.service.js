'use strict';

// Business logic for inventory — called from the controller.
// Keeps controllers thin and services testable.

module.exports = {};
