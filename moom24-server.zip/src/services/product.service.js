'use strict';

// Business logic for product — called from the controller.
// Keeps controllers thin and services testable.

module.exports = {};
