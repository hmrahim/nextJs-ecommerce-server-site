'use strict';

// Business logic for cart — called from the controller.
// Keeps controllers thin and services testable.

module.exports = {};
