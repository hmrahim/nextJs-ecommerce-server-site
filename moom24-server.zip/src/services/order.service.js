'use strict';

// Business logic for order — called from the controller.
// Keeps controllers thin and services testable.

module.exports = {};
