'use strict';

// Business logic for warehouse — called from the controller.
// Keeps controllers thin and services testable.

module.exports = {};
