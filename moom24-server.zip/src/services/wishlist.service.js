'use strict';

// Business logic for wishlist — called from the controller.
// Keeps controllers thin and services testable.

module.exports = {};
