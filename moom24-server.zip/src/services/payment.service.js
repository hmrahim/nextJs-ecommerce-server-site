'use strict';

// Business logic for payment — called from the controller.
// Keeps controllers thin and services testable.

module.exports = {};
