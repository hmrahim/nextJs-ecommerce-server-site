'use strict';

// Business logic for coupon — called from the controller.
// Keeps controllers thin and services testable.

module.exports = {};
