'use strict';

// Business logic for brand — called from the controller.
// Keeps controllers thin and services testable.

module.exports = {};
