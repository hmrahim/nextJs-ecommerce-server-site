'use strict';

module.exports = {
  User:           require('./User'),
  Category:       require('./CategoryModel'),
  Brand:          require('./BrandModel'),
  Product:        require('./ProductModel'),
  ProductVariant: require('./ProductVariantModel'),
  Attribute:      require('./AttributeModel'),
  Warehouse:      require('./Warehouse.model'),
  Inventory:      require('./Inventory.model'),
  Cart:           require('./Cart.model'),
  Coupon:         require('./CouponModel'),
  Order:          require('./Order.model'),
  Payment:        require('./Payment.model'),
  Shipment:       require('./Shipment.model'),
  Review:         require('./ReviewModel'),
  Wishlist:       require('./WishlistModel'),
  Notification:   require('./Notification.model'),
  SearchLog:      require('./SearchLog.model'),
  AuditLog:       require('./AuditLog.model'),
  Banner:         require('./BannerModel'),
  Blog:           require('./BlogModel'),
};