

const mongoose = require('mongoose');
const WishlistModel = require('../models/WishlistModel');

/* ── helpers ─────────────────────────────────────────────────── */
const toId = (id) => new mongoose.Types.ObjectId(String(id));

const populateItems = (doc) =>
  doc.populate({
    path: 'items.product',
    select:
      'name slug images price comparePrice avgRating reviewCount brand inStock stock isActive',
    populate: { path: 'brand', select: 'name logo' },
  });

const serialize = (wishlist) => {
  const items = (wishlist.items || []).filter((i) => {
    if (!i.product) return false;
    if (typeof i.product === 'object' && 'isActive' in i.product) {
      return i.product.isActive !== false;
    }
    return true;
  });
  return {
    _id: wishlist._id,
    items,
    itemCount: items.length,
    updatedAt: wishlist.updatedAt,
  };
};

const validateProductId = (productId, res) => {
  if (!productId || !mongoose.isValidObjectId(String(productId))) {
    res.status(400).json({
      success: false,
      message: 'Invalid or missing productId',
      received: productId,
    });
    return false;
  }
  return true;
};

/* ── GET /api/wishlist ───────────────────────────────────────── */
const getWishlist = async (req, res) => {
  try {
    let wishlist = await WishlistModel.findOne({ user: req.user._id });

    if (!wishlist) {
      wishlist = await WishlistModel.create({ user: req.user._id, items: [] });
    }

    await populateItems(wishlist);
    return res.status(200).json({ success: true, data: serialize(wishlist) });
  } catch (err) {
    console.error('[Wishlist] getWishlist error:', err);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
};

/* ── POST /api/wishlist/items ────────────────────────────────── */
const addItem = async (req, res) => {
  try {
    const productId = req.body?.productId;
    if (!validateProductId(productId, res)) return;

    const pid = toId(productId);

    // Find or create wishlist
    let wishlist = await WishlistModel.findOne({ user: req.user._id });
    if (!wishlist) {
      wishlist = await WishlistModel.create({ user: req.user._id, items: [] });
    }

    // Duplicate check
    const alreadyIn = wishlist.items.some((i) => i.product?.equals(pid));
    if (!alreadyIn) {
      wishlist.items.push({ product: pid, addedAt: new Date() });
      await wishlist.save();
    }

    await populateItems(wishlist);
    return res.status(200).json({
      success: true,
      message: alreadyIn ? 'Already in wishlist' : 'Added to wishlist',
      action: 'added',
      data: serialize(wishlist),
    });
  } catch (err) {
    console.error('[Wishlist] addItem error:', err, 'body:', req.body);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
};

/* ── DELETE /api/wishlist/items/:productId ───────────────────── */
const removeItem = async (req, res) => {
  try {
    const { productId } = req.params;
    if (!validateProductId(productId, res)) return;

    const pid = toId(productId);

    let wishlist = await WishlistModel.findOne({ user: req.user._id });
    if (!wishlist) {
      wishlist = await WishlistModel.create({ user: req.user._id, items: [] });
    }

    wishlist.items = wishlist.items.filter((i) => !i.product?.equals(pid));
    await wishlist.save();

    await populateItems(wishlist);
    return res.status(200).json({
      success: true,
      message: 'Removed from wishlist',
      action: 'removed',
      data: serialize(wishlist),
    });
  } catch (err) {
    console.error('[Wishlist] removeItem error:', err);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
};

/* ── POST /api/wishlist/toggle ───────────────────────────────── */
const toggleItem = async (req, res) => {
  try {
    const productId = req.body?.productId;
    if (!validateProductId(productId, res)) return;

    const pid = toId(productId);

    let wishlist = await WishlistModel.findOne({ user: req.user._id });
    if (!wishlist) {
      wishlist = await WishlistModel.create({ user: req.user._id, items: [] });
    }

    const alreadyIn = wishlist.items.some((i) => i.product?.equals(pid));

    if (alreadyIn) {
      wishlist.items = wishlist.items.filter((i) => !i.product?.equals(pid));
    } else {
      wishlist.items.push({ product: pid, addedAt: new Date() });
    }

    await wishlist.save();
    await populateItems(wishlist);

    const action = alreadyIn ? 'removed' : 'added';
    return res.status(200).json({
      success: true,
      message: action === 'added' ? 'Added to wishlist' : 'Removed from wishlist',
      action,
      data: serialize(wishlist),
    });
  } catch (err) {
    console.error('[Wishlist] toggleItem error:', err);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
};

/* ── DELETE /api/wishlist ────────────────────────────────────── */
const clearWishlist = async (req, res) => {
  try {
    let wishlist = await WishlistModel.findOne({ user: req.user._id });
    if (!wishlist) {
      return res.status(200).json({
        success: true,
        message: 'Wishlist cleared',
        data: { items: [], itemCount: 0 },
      });
    }

    wishlist.items = [];
    await wishlist.save();

    return res.status(200).json({
      success: true,
      message: 'Wishlist cleared',
      data: { items: [], itemCount: 0 },
    });
  } catch (err) {
    console.error('[Wishlist] clearWishlist error:', err);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
};

/* ── GET /api/wishlist/check/:productId ──────────────────────── */
const checkItem = async (req, res) => {
  try {
    const { productId } = req.params;
    if (!validateProductId(productId, res)) return;

    const pid = toId(productId);
    const wishlist = await WishlistModel.findOne({ user: req.user._id }).lean();
    const inWishlist = wishlist
      ? wishlist.items.some((i) => i.product?.toString() === pid.toString())
      : false;

    return res.status(200).json({ success: true, data: { inWishlist } });
  } catch (err) {
    console.error('[Wishlist] checkItem error:', err);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
};

/* ── POST /api/wishlist/move-to-cart ─────────────────────────── */
const moveAllToCart = async (req, res) => {
  try {
    const wishlist = await WishlistModel.findOne({ user: req.user._id }).populate(
      'items.product',
      'name price comparePrice inStock stock'
    );

    if (!wishlist || wishlist.items.length === 0) {
      return res.status(400).json({ success: false, message: 'Wishlist is empty' });
    }

    const Cart = require('../models/Cart.model');

    let cart = await Cart.findOne({ userId: req.user._id });
    if (!cart) cart = new Cart({ userId: req.user._id, items: [] });

    const skipped = [];
    for (const wi of wishlist.items) {
      const prod = wi.product;
      if (!prod || !prod.inStock) {
        skipped.push(prod?.name || 'Unknown');
        continue;
      }
      const exists = cart.items.find((ci) => ci.productId?.equals(prod._id));
      if (!exists) {
        cart.items.push({
          productId: prod._id,
          qty: 1,
          variantSku: 'default',
          price: prod.price ?? 0,
        });
      }
    }

    await cart.save();
    wishlist.items = [];
    await wishlist.save();

    return res.status(200).json({
      success: true,
      message: skipped.length
        ? `Items moved to cart. Skipped out-of-stock: ${skipped.join(', ')}`
        : 'All items moved to cart',
      data: { skipped },
    });
  } catch (err) {
    console.error('[Wishlist] moveAllToCart error:', err);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
};

module.exports = {
  getWishlist,
  addItem,
  removeItem,
  toggleItem,
  clearWishlist,
  checkItem,
  moveAllToCart,
};