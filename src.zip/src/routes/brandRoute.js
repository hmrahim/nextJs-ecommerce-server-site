// 📁 PATH: src/routes/brandRoutes.js
'use strict';

const express = require('express');
const { adminGetBrandStats, adminReorderBrands, adminGetAllBrands, adminCreateBrand, adminGetBrandById, adminUpdateBrand, adminDeleteBrand, adminToggleBrand, adminFeatureBrand, getAllBrands, getBrandBySlug } = require('../controllers/brandController');
const router = express.Router();


/* ══════════════════════════════════════════════════════════════════════════════
   ADMIN ROUTES  —  /api/admin/brands
══════════════════════════════════════════════════════════════════════════════ */

// Stats & Reorder — /:id এর আগে রাখতে হবে
router.get('/admin/brands/stats', adminGetBrandStats);
router.patch('/admin/brands/reorder', adminReorderBrands);

// CRUD
router.get('/admin/brands', adminGetAllBrands);
router.post('/admin/brands', adminCreateBrand);
router.get('/admin/brands/:id', adminGetBrandById);
router.put('/admin/brands/:id', adminUpdateBrand);
router.delete('/admin/brands/:id', adminDeleteBrand);

// Toggle patches
router.patch('/admin/brands/:id/toggle', adminToggleBrand);
router.patch('/admin/brands/:id/feature', adminFeatureBrand);

/* ══════════════════════════════════════════════════════════════════════════════
   PUBLIC ROUTES
══════════════════════════════════════════════════════════════════════════════ */
router.get('/brands', getAllBrands);
router.get('/brands/:slug', getBrandBySlug);

module.exports = router;

// ─── app.js তে এভাবে mount করো ───────────────────────────────────────────────
//
//  const brandRouter = require('./routes/brandRoutes');
//  app.use('/api', brandRouter);