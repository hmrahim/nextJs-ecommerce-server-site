
const express = require('express');
const router = express.Router();



const { adminGetStats, adminReorder, adminGetAll, adminCreate, adminGetById, adminUpdate, adminDelete, adminToggle, adminAddValue, adminReorderValues, adminUpdateValue, adminDeleteValue, publicGetAll, publicGetByCategory } = require('../controllers/attributecontroller');



/* ══════════════════════════════════════════════════════════════════════════════
   ADMIN ROUTES  —  /api/admin/attributes
══════════════════════════════════════════════════════════════════════════════ */

// Stats — /reorder এর আগে রাখো নাহলে ':id' এ match করে
router.get('/admin/attributes/stats', adminGetStats);
router.patch('/admin/attributes/reorder', adminReorder);

// CRUD
router.get('/admin/attributes', adminGetAll);
router.post('/admin/attributes', adminCreate);
router.get('/admin/attributes/:id', adminGetById);
router.put('/admin/attributes/:id', adminUpdate);
router.delete('/admin/attributes/:id', adminDelete);
router.patch('/admin/attributes/:id/toggle', adminToggle);

// Value-level
router.post('/admin/attributes/:attrId/values', adminAddValue);
router.patch('/admin/attributes/:attrId/values/reorder', adminReorderValues);
router.put('/admin/attributes/:attrId/values/:valId', adminUpdateValue);
router.delete('/admin/attributes/:attrId/values/:valId', adminDeleteValue);

/* ══════════════════════════════════════════════════════════════════════════════
   PUBLIC ROUTES
══════════════════════════════════════════════════════════════════════════════ */
router.get('/attributes', publicGetAll);
router.get('/categories/:categoryId/attributes', publicGetByCategory);

module.exports = router;