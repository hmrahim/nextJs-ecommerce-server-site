
const express = require('express');
const router = express.Router();
const { signupController, signinController } = require('../controllers/authController');
// Public routes
router.post('/register',signupController);
router.post('/signin',signinController);
// router.post('/login', authController.signinController);
// router.post('/forgot-password', authController.forgotPasswordController);
// router.patch('/reset-password/:token', authController.resetPasswordController);


module.exports = router;
