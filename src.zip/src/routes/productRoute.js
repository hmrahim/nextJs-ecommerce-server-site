// routes/productRoutes.js  (অথবা তোমার existing file যেটাই হোক)
const express = require('express');
const {
  createProduct,
  getAllProducts,
  getProductById,
  updateProduct,
  deleteProduct,
  hardDeleteProduct,
  updateStatus,
  updateStock,
} = require('../controllers/productController/productControllerAdmin');

const router = express.Router();

// ── GET ──────────────────────────────────────────────────────────────
router.get('/admin/products',     getAllProducts);
router.get('/admin/products/:id', getProductById);

// ── POST ─────────────────────────────────────────────────────────────
router.post('/admin/products',    createProduct);

// ── PUT ──────────────────────────────────────────────────────────────
router.put('/admin/products/:id', updateProduct);

// ── PATCH ─────────────────────────────────────────────────────────────
router.patch('/admin/products/:id/status', updateStatus);
router.patch('/admin/products/:id/stock',  updateStock);

// ── DELETE ────────────────────────────────────────────────────────────
router.delete('/admin/products/:id',       deleteProduct);      // soft-delete (archive)
router.delete('/admin/products/:id/hard',  hardDeleteProduct);  // permanent delete

module.exports = router;