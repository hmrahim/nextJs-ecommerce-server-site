
const express = require('express');
const { createCategory, getTreeCategories, updateCategory,deleteCategory, toggle } = require('../controllers/Categorys/categoryAdminController');
const { categoryStream } = require('../controllers/sseController');
const router = express.Router();
// =========sse routes========
router.get('/admin/categories/events', categoryStream); // ✅ /admin যোগ করো

// =========admin category routes========
router.post('/admin/categories',createCategory);
router.get('/admin/categories/tree',getTreeCategories);
router.put('/admin/categories/:id', updateCategory);
router.delete('/admin/categories/:id', deleteCategory);
router.patch('/admin/categories/:id/toggle', toggle);

module.exports = router;
