// 📁 PATH: backend/routes/productVariantRoutes.js
const express = require('express');
const { getVariants, createVariant, bulkGenerateVariants, updateVariant, deleteAllVariants, deleteVariant, toggleVariant } = require('../controllers/variantController/productVariantController');
const router = express.Router({ mergeParams: true }); // mergeParams: productId পাওয়ার জন্য


router.get('/admin/products/:productId/variants', getVariants);
router.post('/admin/products/:productId/variants', createVariant);
router.post('/admin/products/:productId/variants/bulk', bulkGenerateVariants);
router.put('/admin/products/:productId/variants/:variantId', updateVariant);
router.delete('/admin/products/:productId/variants', deleteAllVariants);
router.delete('/admin/products/:productId/variants/:variantId', deleteVariant);
router.patch('/admin/products/:productId/variants/:variantId/toggle', toggleVariant);

module.exports = router;


