'use strict';

const Product = require('../models/Product');

/* ─────────────────────────────────────────────
   PUBLIC PRODUCT CONTROLLER
   Routes (example):
     GET  /api/products            → getAllProducts
     GET  /api/products/:slug      → getProductBySlug
     GET  /api/products/sku/:sku   → getProductBySku
     GET  /api/products/search     → searchProducts
   All queries filter: status='active' & isActive=true
───────────────────────────────────────────── */

/* ── helpers ── */
const buildPriceFilter = (min, max) => {
  const filter = {};
  if (min !== undefined) filter.$gte = Number(min);
  if (max !== undefined) filter.$lte = Number(max);
  return Object.keys(filter).length ? filter : null;
};

/* ─────────────────────────────────────────────
   @desc    Get all active products (paginated + filtered)
   @route   GET /api/products
   @access  Public
───────────────────────────────────────────── */
exports.getAllProducts = async (req, res) => {
  try {
    const {
      page = 1,
      limit = 20,
      sort = '-createdAt',
      categoryId,
      subCategoryId,
      subSubCategoryId,
      brandId,
      tags,
      isFeatured,
      minPrice,
      maxPrice,
    } = req.query;

    const filter = { status: 'active', isActive: true };

    if (categoryId)       filter.categoryId       = categoryId;
    if (subCategoryId)    filter.subCategoryId    = subCategoryId;
    if (subSubCategoryId) filter.subSubCategoryId = subSubCategoryId;
    if (brandId)          filter.brandId          = brandId;
    if (isFeatured)       filter.isFeatured       = isFeatured === 'true';
    if (tags)             filter.tags             = { $in: tags.split(',') };

    const priceFilter = buildPriceFilter(minPrice, maxPrice);
    if (priceFilter) filter.basePrice = priceFilter;

    const skip  = (Number(page) - 1) * Number(limit);
    const total = await Product.countDocuments(filter);

    const products = await Product.find(filter)
      .select('-cost -trackInventory')          // hide internal fields
      .populate('categoryId',       'name slug')
      .populate('subCategoryId',    'name slug')
      .populate('subSubCategoryId', 'name slug')
      .populate('brandId',          'name logo')
      .sort(sort)
      .skip(skip)
      .limit(Number(limit))
      .lean({ virtuals: true });

    res.status(200).json({
      success: true,
      total,
      page:    Number(page),
      pages:   Math.ceil(total / Number(limit)),
      results: products,
    });
  } catch (err) {
    console.error('getAllProducts:', err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

/* ─────────────────────────────────────────────
   @desc    Get single product by slug
   @route   GET /api/products/:slug
   @access  Public
───────────────────────────────────────────── */
exports.getProductBySlug = async (req, res) => {
  try {
    const product = await Product.findOne({
      slug:     req.params.slug,
      status:   'active',
      isActive: true,
    })
      .select('-cost -trackInventory')
      .populate('categoryId',       'name slug')
      .populate('subCategoryId',    'name slug')
      .populate('subSubCategoryId', 'name slug')
      .populate('brandId',          'name logo')
      .lean({ virtuals: true });

    if (!product) {
      return res.status(404).json({ success: false, message: 'Product not found' });
    }

    res.status(200).json({ success: true, data: product });
  } catch (err) {
    console.error('getProductBySlug:', err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

/* ─────────────────────────────────────────────
   @desc    Get single product by SKU
   @route   GET /api/products/sku/:sku
   @access  Public
───────────────────────────────────────────── */
exports.getProductBySku = async (req, res) => {
  try {
    const product = await Product.findOne({
      sku:      req.params.sku.toUpperCase(),
      status:   'active',
      isActive: true,
    })
      .select('-cost -trackInventory')
      .populate('categoryId', 'name slug')
      .populate('brandId',    'name logo')
      .lean({ virtuals: true });

    if (!product) {
      return res.status(404).json({ success: false, message: 'Product not found' });
    }

    res.status(200).json({ success: true, data: product });
  } catch (err) {
    console.error('getProductBySku:', err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

/* ─────────────────────────────────────────────
   @desc    Full-text search on name / description / tags
   @route   GET /api/products/search?q=keyword
   @access  Public
───────────────────────────────────────────── */
exports.searchProducts = async (req, res) => {
  try {
    const { q, page = 1, limit = 20 } = req.query;

    if (!q || !q.trim()) {
      return res.status(400).json({ success: false, message: 'Search query (q) is required' });
    }

    const filter = {
      $text:    { $search: q.trim() },
      status:   'active',
      isActive: true,
    };

    const skip  = (Number(page) - 1) * Number(limit);
    const total = await Product.countDocuments(filter);

    const products = await Product.find(filter, { score: { $meta: 'textScore' } })
      .select('-cost -trackInventory')
      .populate('categoryId', 'name slug')
      .populate('brandId',    'name logo')
      .sort({ score: { $meta: 'textScore' } })
      .skip(skip)
      .limit(Number(limit))
      .lean({ virtuals: true });

    res.status(200).json({
      success: true,
      total,
      page:    Number(page),
      pages:   Math.ceil(total / Number(limit)),
      results: products,
    });
  } catch (err) {
    console.error('searchProducts:', err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

/* ─────────────────────────────────────────────
   @desc    Get featured products
   @route   GET /api/products/featured
   @access  Public
───────────────────────────────────────────── */
exports.getFeaturedProducts = async (req, res) => {
  try {
    const { limit = 10 } = req.query;

    const products = await Product.find({
      isFeatured: true,
      status:     'active',
      isActive:   true,
    })
      .select('-cost -trackInventory')
      .populate('categoryId', 'name slug')
      .populate('brandId',    'name logo')
      .sort('-createdAt')
      .limit(Number(limit))
      .lean({ virtuals: true });

    res.status(200).json({ success: true, results: products });
  } catch (err) {
    console.error('getFeaturedProducts:', err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};